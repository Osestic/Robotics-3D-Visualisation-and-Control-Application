# interbotix_ros_xseries

This metapackage groups together the core ROS Packages for the Interbotix X-Series family of products.
